package com.acadgild.myfirstapp.listascdesc;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    ArrayList<String> list;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button asc = (Button)findViewById(R.id.ascending);
        Button desc = (Button)findViewById(R.id.descending);
        final ListView listView = (ListView)findViewById(R.id.listvieww);
        final String[] months = {"January","February","March","April","May","June","July","August","September","October","November","December"};
        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,months);
        listView.setAdapter(adapter);


        asc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                list = new ArrayList<String>(Arrays.asList(months));
                Collections.sort(list);
                ArrayAdapter adapter1 = new ArrayAdapter(MainActivity.this,android.R.layout.simple_list_item_1,list);
                listView.setAdapter(adapter1);
                adapter1.notifyDataSetChanged();
            }

        });

        desc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                list = new ArrayList<String>(Arrays.asList(months));

                Collections.sort(list, new Comparator<String>() {
                    @Override
                    public int compare(String lhs, String rhs) {
                        int res = rhs.compareTo(lhs);
                        return res;
                    }
                });
                ArrayAdapter adapter1 = new ArrayAdapter(MainActivity.this,android.R.layout.simple_list_item_1,list);
                listView.setAdapter(adapter1);
                adapter1.notifyDataSetChanged();
            }
        });
    }


}
