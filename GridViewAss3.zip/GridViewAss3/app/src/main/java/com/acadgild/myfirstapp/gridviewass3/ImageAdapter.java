package com.acadgild.myfirstapp.gridviewass3;

import android.app.ActionBar;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridLayout;
import android.widget.GridView;
import android.widget.ImageView;

/**
 * Created by E9900317 on 4/29/2016.
 */
public class ImageAdapter extends BaseAdapter {

    private Context context;
    public  Integer[]imagearray = {R.drawable.gummy,R.drawable.honeycomb,R.drawable.icecream,R.drawable.jellybeans,R.drawable.lollipop};
    public ImageAdapter(Context context) {
        this.context = context;
    }

    @Override
    public int getCount() {
        return imagearray.length;
    }

    @Override
    public Object getItem(int position) {
        return imagearray[position];
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ImageView imageView;
         if(convertView == null) {
             imageView = new ImageView(context);
             imageView.setLayoutParams(new GridView.LayoutParams(85, 85));
             imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
             imageView.setPadding(8, 8, 8, 8);
             //imageView.setLayoutParams(new GridView());

         }
        else {
             imageView = (ImageView)convertView;

         }
        imageView.setImageResource(imagearray[position]);
        return imageView ;
    }



}

