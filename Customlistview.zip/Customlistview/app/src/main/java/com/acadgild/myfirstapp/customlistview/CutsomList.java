package com.acadgild.myfirstapp.customlistview;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

/**
 * Created by E9900317 on 4/10/2016.
 */
public class CutsomList extends ArrayAdapter<String> {

    private final Activity context;
    private final String[] name;
    private final String[] phno;

    public CutsomList(Activity context, String[] name, String[] phno) {
        super(context, R.layout.customized, name);
        // TODO Auto-generated constructor stub

        this.context=context;
        this.name=name;
        this.phno=phno;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater layoutInflater = context.getLayoutInflater();
        View view = layoutInflater.inflate(R.layout.customized, null, true);
        TextView tname = (TextView)view.findViewById(R.id.name);
        TextView tphno = (TextView)view.findViewById(R.id.phone);
        //name.setText(name[position]);
        tname.setText(name[position]);
        tphno.setText(phno[position]);

        return view;
    }
}
