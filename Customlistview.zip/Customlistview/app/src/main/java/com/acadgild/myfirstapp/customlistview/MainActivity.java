package com.acadgild.myfirstapp.customlistview;

import android.content.Context;
import android.database.Cursor;
import android.support.v4.widget.CursorAdapter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        final String[] name = {" Sonali","Shreya","Priya","Khush","Tanay","Devang","Ankit"};
        String[] phno = {"9420033165","9923004021","9923003292","9960869365","9405567416","7276826040","9405570507","9422080665","9860019001","9423791917"};

        CutsomList cutsomList = new CutsomList(MainActivity.this,name,phno);
        ListView listView = (ListView)findViewById(R.id.listview);
        listView.setAdapter(cutsomList);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String sel = name[+position];
                Toast.makeText(MainActivity.this,sel,Toast.LENGTH_SHORT).show();

            }
        });



    }
}
